﻿namespace SERVER
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;


        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            logservidor = new TextBox();
            label1 = new Label();
            IP = new TextBox();
            textBox3 = new TextBox();
            label2 = new Label();
            Porta = new Label();
            Iniciar = new Button();
            Encerrar = new Button();
            SuspendLayout();
            // 
            // logservidor
            // 
            logservidor.Location = new Point(27, 82);
            logservidor.Multiline = true;
            logservidor.Name = "logservidor";
            logservidor.ScrollBars = ScrollBars.Both;
            logservidor.Size = new Size(603, 339);
            logservidor.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Location = new Point(27, 64);
            label1.Name = "label1";
            label1.Size = new Size(90, 15);
            label1.TabIndex = 1;
            label1.Text = "Log do Servidor";
            label1.Click += label1_Click;
            // 
            // IP
            // 
            IP.Location = new Point(48, 23);
            IP.Name = "IP";
            IP.Size = new Size(129, 23);
            IP.TabIndex = 2;
            IP.Text = "127.0.0.1";
            IP.TextChanged += IP_TextChanged;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(216, 23);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(56, 23);
            textBox3.TabIndex = 3;
            textBox3.Text = "5555";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Location = new Point(27, 27);
            label2.Name = "label2";
            label2.Size = new Size(17, 15);
            label2.TabIndex = 4;
            label2.Text = "IP";
            label2.Click += label2_Click;
            // 
            // Porta
            // 
            Porta.AutoSize = true;
            Porta.FlatStyle = FlatStyle.Flat;
            Porta.Location = new Point(182, 27);
            Porta.Name = "Porta";
            Porta.Size = new Size(35, 15);
            Porta.TabIndex = 5;
            Porta.Text = "Porta";
            // 
            // Iniciar
            // 
            Iniciar.Location = new Point(284, 13);
            Iniciar.Name = "Iniciar";
            Iniciar.Size = new Size(105, 43);
            Iniciar.TabIndex = 6;
            Iniciar.Text = "Iniciar";
            Iniciar.UseVisualStyleBackColor = true;
            Iniciar.Click += Iniciar_Click;
            // 
            // Encerrar
            // 
            Encerrar.Location = new Point(400, 13);
            Encerrar.Name = "Encerrar";
            Encerrar.Size = new Size(112, 43);
            Encerrar.TabIndex = 7;
            Encerrar.Text = "Encerrar";
            Encerrar.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(653, 450);
            Controls.Add(Encerrar);
            Controls.Add(Iniciar);
            Controls.Add(Porta);
            Controls.Add(label2);
            Controls.Add(textBox3);
            Controls.Add(IP);
            Controls.Add(label1);
            Controls.Add(logservidor);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label label2;
        private Label Porta;
        public TextBox logservidor;
        public TextBox IP;
        public TextBox textBox3;
        public Button Iniciar;
        public Button Encerrar;
    }
}
