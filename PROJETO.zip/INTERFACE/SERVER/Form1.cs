using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace SERVER
{
    public partial class Form1 : Form
    {
        static Dictionary<string, TcpClient> clients = new Dictionary<string, TcpClient>();
        public Form1()
        {
            InitializeComponent();

        }

        void Iniciar_Click(object sender, EventArgs e)
        {

            TcpListener server = new TcpListener(IPAddress.Any, 55555);
            server.Start();

            Console.WriteLine("Servidor ouvindo na porta 55555");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                Thread clientThread = new Thread(() => HandleClient(client));
                clientThread.Start();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void IP_TextChanged(object sender, EventArgs e)
        {

        }

        void HandleClient(TcpClient tcpClient)
        {
            NetworkStream stream = tcpClient.GetStream();
            byte[] data = new byte[1024];
            int bytesRead;



            // Solicita o nome de usu�rio ao cliente
            //SendData(stream, "Digite seu nome de usu�rio: ");
            string username = ReceiveData(stream);

            SendData(stream, $"Conectado com sucesso ao servidor de mensagens!");
            // Adiciona o cliente ao dicion�rio
            clients.Add(username, tcpClient);
            SendOnlineMembersList();

            // Notifica os outros clientes sobre a entrada do novo usu�rio
            Broadcast($"{username} entrou no chat.");


            Console.WriteLine($"{username} conectado");
            logservidor.Text += $"{username} conectado{Environment.NewLine}";

            while (true)
            {
                try
                {
                    bytesRead = stream.Read(data, 0, data.Length);
                    if (bytesRead == 0)
                        break;

                    string message = Encoding.UTF8.GetString(data, 0, bytesRead);

                    // L�gica para direcionar mensagens privadas
                    if (message.StartsWith("/"))
                    {
                        string[] parts = message.Split(' ');
                        string recipient = parts[1];
                        string privateMessage = string.Join(' ', parts, 2, parts.Length - 2);

                        if (clients.ContainsKey(recipient))
                        {
                            SendData(clients[recipient].GetStream(), $"{username} (privado): {privateMessage}");
                            SendData(stream, $"Mensagem privada enviada para {recipient}.");
                        }
                        else
                        {
                            SendData(stream, $"Usu�rio {recipient} n�o encontrado.");
                        }
                    }
                    // L�gica para tratar comandos especiais
                    else if (message.StartsWith("/lista"))
                    {
                        string userList = "Usu�rios conectados: " + string.Join(", ", clients.Keys);
                        SendData(stream, userList);
                    }
                    else if (message.ToLower() == "exit")
                    {
                        break;
                    }
                    else
                    {
                        Broadcast($"{username}: {message}");
                    }
                }
                catch
                {
                    break;
                }
            }

            // Ao sair do loop, remova o cliente do dicion�rio
            clients.Remove(username);
            Broadcast($"{username} saiu do chat.");

            Console.WriteLine($"{username} desconectado");
            logservidor.Text += $"{username} desconectado{Environment.NewLine}";

            tcpClient.Close();
        }

        static void Broadcast(string message)
        {
            foreach (var client in clients.Values)
            {
                SendData(client.GetStream(), message);
            }
        }

        static void SendOnlineMembersList()
        {
            foreach (var client in clients)
            {
                string chave = client.Key;
                SendClientInfo(chave);
            }
        }

        static void SendData(NetworkStream stream, string message)
        {
            // Serializa o objeto de mensagem para JSON


            // Formata a mensagem serializada com o prefixo "MSG:"


            // Converte a mensagem formatada em bytes
            byte[] data = Encoding.UTF8.GetBytes(message);

            // Envia os dados para o cliente atrav�s da stream fornecida
            stream.Write(data, 0, data.Length);
        }

        static string ReceiveData(NetworkStream stream)
        {
            byte[] data = new byte[1024];
            int bytesRead = stream.Read(data, 0, data.Length);
            return Encoding.UTF8.GetString(data, 0, bytesRead);
        }

        static void SendClientInfo(String Name)
        {
            Name = Name + "-";
            Broadcast(Name);
        }


    }
}
